#include "answer06.h"
#include <strings.h>
#include <stdio.h>
#include <stdlib.h>
void help(CardDeck upperdeck, CardDeck lowerdeck,int j, int p);
// You may add more functions in this file.

// do NOT modify any #ifdef or #endif
// they are used for giving partial credits

// The following line must be above divideDeck
#ifdef TEST_DIVIDE 
void divideDeck(CardDeck origdeck, 
		CardDeck * upperdeck, CardDeck * lowerdeck)
{
  // if the original deck has n cards, there are n - 1 pairs of
  // upper and low decks: 
  // 1.   upper deck has 1 card,      low deck has n - 1 cards
  // 2.   upper deck has 2 cards,     low deck has n - 2 cards
  // 3.   upper deck has 3 cards,     low deck has n - 3 cards
  // ...
  // n-1. upper deck has n - 1 cards, low deck has 1 cards
  
  // upperdeck[0] should store the first card in the original deck
  // upperdeck[1] should store the top two cards in the original deck
  // upperdeck[2] should store the top three cards in the original deck

  // be careful that in CardDeck, cards is an array (thus a pointer)	
	int i;
	for(i = 1;i < origdeck.size;i++){
		bcopy(origdeck.cards,upperdeck[i-1].cards ,i*sizeof(char));
		upperdeck[i-1].size = i;
		bcopy(origdeck.cards+i,lowerdeck[i-1].cards,(origdeck.size-i)*sizeof(char));
		lowerdeck[i-1].size = (origdeck.size-i);
	}
}
#endif
// The previous line must be below divideDeck

#ifdef TEST_INTERLEAVE
// reuse what you wrote for PE05
void interleave(CardDeck upperdeck, 
		CardDeck lowerdeck){
  // create a new deck storing the result
  // this new deck's size should be the sum of the
  // sizes of upperdeck and lowerdeck
	CardDeck outdeck;
	outdeck.size = upperdeck.size + lowerdeck.size;
 
	

	if (upperdeck.size > lowerdeck.size){
		help(upperdeck, lowerdeck, lowerdeck.size, upperdeck.size);
	}else{
		help(lowerdeck, upperdeck, upperdeck.size,lowerdeck.size);
	}
		
}


 

void help(CardDeck upperdeck, CardDeck lowerdeck,int j, int p){
	if (j == 0){
		printDeck(upperdeck);
		return;
	}
	CardDeck temp_upper;
	CardDeck temp_lower;
	int i;	

	temp_upper.size = upperdeck.size + 1;
	temp_lower.size = lowerdeck.size - 1;	

	for(i = p; i >= 0;  i-- ){
		bcopy(upperdeck.cards,temp_upper.cards,i*sizeof(char));
		bcopy(&lowerdeck.cards[j-1],&temp_upper.cards[i],sizeof(char));
		bcopy(&upperdeck.cards[i],&temp_upper.cards[i+1],(upperdeck.size - i)*sizeof(char));
		bcopy(lowerdeck.cards,temp_lower.cards,j*sizeof(char));
		
		p = i;
		help(temp_upper,temp_lower,j - 1, p);
	}
}


#endif

#ifdef TEST_SHUFFLE
void shuffle(CardDeck origdeck)
{
  // origdeck contains the number of cards
  // the number of upper-low deck pairs should be 
  //     the number of cards - 1
  // this function has the following steps:
  //    calculate the number of upper-low deck pairs
  //    allocate enough memory to accommodate the pairs
  //    call divideDeck to find these pairs
  //    for each pair of upper-lower deck, interleave the cards
  //    release the allocated memory
  // 
  // The amount of memory allocated in this function must be
  // determined based on the size of the original deck. The program
  // may fail if the allocated memory has a fixed size (some students
  // like to use 1000 but nobody could explain why 1000).  If you do
  // not know how much memory to allocate, please refer to PE05's
  // README.
  // 
  // You will lose 50% points if the amount of allocated memory is not
  // determined by the size of the original deck.  To be more precise,
  // you will use 50% point if you use 100, 1000, 10000 (or any other
  // fixed number) without clear explanation.
  //

  // the following code gives you some hints. You may make any changes
  // as appropriate;
  int numpairs = -1;
  
  CardDeck * upperdeck = NULL;
  CardDeck * lowerdeck = NULL;

  // allocate memory
  if (upperdeck == NULL)
    {
	upperdeck = (CardDeck*)malloc(sizeof(CardDeck)*MAX_SIZE);
    }
  if (lowerdeck == NULL)
    {
	lowerdeck = (CardDeck*)malloc(sizeof(CardDeck)*MAX_SIZE);
    }
  
  // call divideDeck to fill upperdeck and lowerdeck
  divideDeck(origdeck, upperdeck, lowerdeck);
  numpairs = origdeck.size - 1;	
  
  while (numpairs > 0)
    {
      // for each pairs call interleave
	numpairs--;
    	interleave(upperdeck[numpairs],lowerdeck[numpairs]);
    }
    free(upperdeck);
    free(lowerdeck);
} 
#endif
