#include "answer02.h"
#include "stdlib.h"
#include "stdio.h"
#include "string.h"

void help(CardDeck upperdeck, CardDeck lowerdeck,int j, int p, int k);
void divideDeck(CardDeck origdeck, CardDeck * upperdeck, CardDeck * lowerdeck);
void interleave(CardDeck upperdeck, CardDeck lowerdeck,int k);
// You can add more functions to this file.
//
// If you allocate for space, you are responsible for freeing the space
// 
// You will lose 50% points if the amount of allocated memory is not
// determined by the size of the original deck.  To be more precise,
// you will lose 50% point if you use 100, 1000, 10000 (or any other
// fixed number) without clear explanation.
//

void repeatShuffle(CardDeck origdeck, int k)
{
  // origdeck contains the number of cards
  // the number of upper-low deck pairs should be 
  //     the number of cards - 1
  // this function has the following steps:
  //    if (k <= 0), no shuffling, print the only possible outcome
  //    otherwise, 
  //       for each pair of upper and lower decks, interleave the cards,
  //           when the interleaving is complete, have to perform another 
  //           k-1 rounds of shuffling with the new deck
  //
  // Print only the results obtained after k rounds of shuffling
  // see interleave in PE05 and shuffle in PE06 for more details
	if (k < 0){
		return;
	}
	if(k == 0){
		printDeck(origdeck);
		return;
	}
  	int numpairs = -1;
  
  	CardDeck * upperdeck = NULL;
  	CardDeck * lowerdeck = NULL;

  	// allocate memory
  	if (upperdeck == NULL)
    	{
		upperdeck = (CardDeck*)malloc(sizeof(CardDeck)*MAX_SIZE);
    	}
  	if (lowerdeck == NULL)
    	{
		lowerdeck = (CardDeck*)malloc(sizeof(CardDeck)*MAX_SIZE);
    	}
  
  	// call divideDeck to fill upperdeck and lowerdeck
  	divideDeck(origdeck, upperdeck, lowerdeck);
  	numpairs = origdeck.size - 1;	
  
  	while (numpairs > 0)
    	{
      	// for each pairs call interleave
		numpairs--;
    		interleave(upperdeck[numpairs],lowerdeck[numpairs],k);
    	}
    	free(upperdeck);
    	free(lowerdeck);
}



 
void divideDeck(CardDeck origdeck, CardDeck * upperdeck, CardDeck * lowerdeck)
{
	int i;
	for(i = 1;i < origdeck.size;i++){
		bcopy(origdeck.cards,upperdeck[i-1].cards ,i*sizeof(char));
		upperdeck[i-1].size = i;
		bcopy(origdeck.cards+i,lowerdeck[i-1].cards,(origdeck.size-i)*sizeof(char));
		lowerdeck[i-1].size = (origdeck.size-i);
	}
}


void interleave(CardDeck upperdeck, CardDeck lowerdeck,int k){
	CardDeck outdeck;
	outdeck.size = upperdeck.size + lowerdeck.size;
 
	

	if (upperdeck.size > lowerdeck.size){
		help(upperdeck, lowerdeck, lowerdeck.size, upperdeck.size,k);
	}else{
		help(lowerdeck, upperdeck, upperdeck.size,lowerdeck.size,k);
	}
		
}
 
void help(CardDeck upperdeck, CardDeck lowerdeck,int j, int p, int k){
	if (j == 0){
		repeatShuffle(upperdeck, k - 1);
		return;
	}
	CardDeck temp_upper;
	CardDeck temp_lower;
	int i;	

	temp_upper.size = upperdeck.size + 1;
	temp_lower.size = lowerdeck.size - 1;	

	for(i = p; i >= 0;  i-- ){
		bcopy(upperdeck.cards,temp_upper.cards,i*sizeof(char));
		bcopy(&lowerdeck.cards[j-1],&temp_upper.cards[i],sizeof(char));
		bcopy(&upperdeck.cards[i],&temp_upper.cards[i+1],(upperdeck.size - i)*sizeof(char));
		bcopy(lowerdeck.cards,temp_lower.cards,j*sizeof(char));
		
		p = i;
		help(temp_upper,temp_lower,j - 1, p, k);
	}
}


/*
#ifdef TEST_SHUFFLE
void shuffle(CardDeck origdeck,int k)
{
  int numpairs = -1;
  
  CardDeck * upperdeck = NULL;
  CardDeck * lowerdeck = NULL;

  // allocate memory
  if (upperdeck == NULL)
    {
	upperdeck = (CardDeck*)malloc(sizeof(CardDeck)*MAX_SIZE);
    }
  if (lowerdeck == NULL)
    {
	lowerdeck = (CardDeck*)malloc(sizeof(CardDeck)*MAX_SIZE);
    }
  
  // call divideDeck to fill upperdeck and lowerdeck
  divideDeck(origdeck, upperdeck, lowerdeck);
  numpairs = origdeck.size - 1;	
  
  while (numpairs > 0)
    {
      // for each pairs call interleave
	numpairs--;
    	interleave(upperdeck[numpairs],lowerdeck[numpairs],k);
    }
    free(upperdeck);
    free(lowerdeck);
} 
#endif
*/
