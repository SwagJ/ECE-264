#ifndef PE04_H
#define PE04_H 

// handle the sign, call the recursive function to print the 
// magnitude, set the errno if base is invalid
//
char *long_int_to_string(long int number, int base);

#endif
