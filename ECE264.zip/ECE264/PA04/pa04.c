#include <stdio.h>
#include <stdlib.h>
#include "answer04.h"

int main(int argc, char* argv[])
{
   if (argc != 5){
      return EXIT_FAILURE;
   }
   if (argv[1] == NULL){
      return EXIT_FAILURE;
   }
   if (argv[2] == NULL){
      return EXIT_FAILURE;
   }
   if (argv[3] == NULL){
      return EXIT_FAILURE;
   }
   if (argv[4] == NULL){
      return EXIT_FAILURE;
   }

   long* ascii = NULL;
   ascii_check(argv[1],&ascii);

   lnode* list = NULL;
   list_form(argv[1],ascii,&list);

   lnode* tree = NULL;
   tree = hf_tree(argv[2],list);
   post_print(tree,argv[3],argv[4]);
   //free(tree);
   //free(list);
   free(ascii);
   return EXIT_SUCCESS;
}
