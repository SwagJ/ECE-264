#include <stdlib.h>
#include <stdio.h>
#include "answer04.h"

// Function from PE10 to do ascii check

void ascii_check(char* inputfile, long** ascii_value){
   int i;
   *ascii_value = malloc(sizeof(long)*256);
   if (*ascii_value == NULL){
      return;
   }

   for (i = 0; i < 256; i++) {
      (*ascii_value)[i] = 0;
   }

   if (inputfile == NULL){
      return;
   }

   FILE* iptr = fopen(inputfile,"r");
   if(iptr == NULL){
      return;
   }
   fseek(iptr,0,SEEK_END);
   long length = ftell(iptr);
    if (length == 0){
      return;
   }

   fseek(iptr,0,SEEK_SET);
   int ch;
   while((ch = fgetc(iptr))!=EOF){
       (*ascii_value)[ch] ++;
   }
  
   fclose(iptr);
   return;
}

// help function to enqueue link list

lnode *PQ_enqueue(lnode **pq, char new_word, long new_weight, 
                  int (*cmp_fn)(long,long))
{
   if(new_weight == 0){
   	return NULL;
   }
   lnode* n_ob = (lnode*)malloc(sizeof(lnode)*1);
   if (n_ob == NULL){
      return NULL;
   }
   n_ob->weight = new_weight;
   n_ob->word = new_word;
   n_ob->next = NULL;
   n_ob->left = NULL;
   n_ob->right = NULL;

   lnode dummy;
   dummy.next = *pq;

   lnode* prev = &dummy;
   lnode* curr = *pq;
   while (curr != NULL){
      if (cmp_fn(curr->weight, new_weight)){
         break;
      }else{
         prev = curr;
         curr = curr->next;
      }
   }
   prev->next = n_ob;
   n_ob->next = curr;
   *pq = dummy.next;

   return NULL;
}

// PE10 function to form link list needed to construct hoffman coding tree

void list_form(char* inputfile, long* countarr, lnode** list){
   if (countarr == NULL){
      return;
   } 
   
   if (inputfile == NULL){
      return;
   }

   int i = 0;

   //*list = malloc(sizeof(lnode));
   for (i = 0; i < 256; i++){
      PQ_enqueue(list,(char)i,countarr[i],compare);
   }

   //lnode_print(optr,list);
   //free(countarr);
   return;
}

// Construct hoffman coding tree

lnode* hf_tree(char* outputfile, lnode* list){
   if (outputfile == NULL){
      return NULL;
   }
   if (list == NULL){
      return NULL;
   }
   lnode* cur = list;
   while(cur != NULL){
   	cur->right = NULL;
   	cur->left = NULL;
   	cur = cur->next;
   }
   lnode** tree = &list;
   hf_tree_helper(tree);
   
   FILE* ptr;
   ptr = fopen(outputfile,"w");
   if (ptr == NULL){
      return NULL ;
   }

   char* print_arr;
   print_arr = malloc(sizeof(char)*500);
   if (print_arr == NULL){
      fclose(ptr);
      return NULL;
   }

   print_to_file_fn(ptr,*tree,print_arr,0);
   fclose(ptr);
   free(print_arr);
   return list;
}




//Helper Functions
//
//
//
//Start

// stack pop function

lnode *pop(lnode **list)
{
   if (*list == NULL) {
      return NULL;
   }
   lnode *new_node = *list;
   *list = new_node->next;
   new_node->next = NULL;
   return new_node;
}

// revised enqueue function for tree construction


lnode *enqueue(lnode **pq, lnode* tree,
                  int (*cmp_fn)(long,long))
{
   if (tree == NULL){
      return NULL;
   }
   
   lnode dummy;
   dummy.next = *pq;

   lnode* prev = &dummy;
   lnode* curr = *pq;
   while (curr != NULL){
      if (cmp_new(tree->weight,curr->weight)){
         break;
      }else{
         prev = curr;
         curr = curr->next;
      }
   }
   prev->next = tree;
   tree->next = curr;
   *pq = dummy.next;

   return NULL;
}

// new compare function

int cmp_new(long a, long b){
   if (a < b){
      return 1;
   }
   return 0;
}

// tree construct helper function

void hf_tree_helper(lnode** list){
   if ((*list)->next == NULL){ 
   	return;
   }
   lnode* temp1,*temp2;
   lnode* tree = (lnode*)malloc(sizeof(lnode));   
   temp1 = pop(list);
   temp2 = pop(list);
   tree->left = temp1;
   tree->right = temp2;
   tree->weight = temp1->weight+temp2->weight;
   enqueue(list, tree, cmp_new);
   hf_tree_helper(list);
}

// read file chars into array

int* file_to_array(FILE* fptr, long* count){
   if (fptr == NULL){
      return NULL;
   }
   
   int ch;
   
   fseek(fptr, 0, SEEK_END);
   *count = ftell(fptr);
   
   int* array = malloc(sizeof(int)*(*count));

   int j = 0;
   fseek(fptr, 0, SEEK_SET);
   while((ch = fgetc(fptr)) && ch != EOF){
      array[j++] = ch;
   }

   return array;
}

// print tree to output file
   
void lnode_print(FILE* fptr, const lnode *list)
{
   while (list != NULL) {
      // print the memory associated with list->ptr
      fprintf(fptr, "%c:%ld", list->word,list->weight);
      // print an arrow
      fprintf(fptr, "->");
      list = list->next;
   } 
   // print NULL and a newline after that 
   fprintf(fptr, "NULL\n");
} 

// compare function

int compare(long weight_old, long weight_new){
   if(weight_old > weight_new){
      return 1;
   }
	return 0;
}

//  print file function

void print_to_file_fn(FILE* ptr, lnode* tree, char* print_arr, int index){
   if ((tree->left == NULL)&&(tree->right == NULL)){
      fprintf(ptr,"%c:", tree->word);
      print_arr[index] = '\0';
      int i = 0;
      while(print_arr[i] != '\0'){
         fprintf(ptr,"%c",print_arr[i]);
         i++;
      }
      fprintf(ptr,"\n");
      return;
   }
   
   if (tree->left != NULL){
      print_arr[index] = '0';
      print_to_file_fn(ptr,tree->left,print_arr,index+1);
   }

   if (tree->right != NULL){
      print_arr[index] = '1';
      print_to_file_fn(ptr,tree->right,print_arr,index+1);
   }
   return;
}   


//PA04
//
//
//
//

void post_print(lnode* tree, char* outputfile, char* outputfile2){
   if (tree == NULL){
      return;
   }
   FILE* ptr = fopen(outputfile,"w");
   if (ptr == NULL){
      return;
   }
   FILE* iptr = fopen(outputfile2,"w");
   if (iptr == NULL){
      return;
   }
   char* prev_left = malloc(sizeof(char));
   int* index = malloc(sizeof(int));
   *index = 0;
   *prev_left = 0x00;
   post_print_helper(tree, ptr, iptr, prev_left,index);
   fprintf(ptr,"0");
   bit_0_print(index, prev_left,iptr);
   if(*index != 0){
      fputc(*prev_left,iptr);
   }
   fclose(ptr);
   fclose(iptr);
   free(prev_left);
   free(index);
   return;
}


void post_print_helper(lnode* tree, FILE* ptr,FILE* iptr, char* prev_left, int* index){
   if (tree == NULL){
      printf("ERROR! Tree is NULL. index = %d\n", *index);
   }
   if ((tree != NULL)&&(tree->left == NULL)&&(tree->right == NULL)){
      fprintf(ptr,"1%c",tree->word);
      bit_1_print(tree->word,index,prev_left,iptr);
      free(tree);
      return;
   }

   post_print_helper(tree->left,ptr,iptr,prev_left,index);
   post_print_helper(tree->right,ptr,iptr,prev_left, index);
   fprintf(ptr, "0");
   bit_0_print(index, prev_left, iptr);
   free(tree);
   return;
}

void bit_1_print(char word, int* index, char* prev_left, FILE* fptr){
   char Pre = *prev_left;
   unsigned char mask = 0xFF;
   unsigned char bit1 = (0x80)>>(*index)++;
   unsigned char first_bit = Pre | bit1;
   unsigned char post;
   unsigned char out_byte = first_bit;
   
   if(*index == 8)
   {
      *index = 0;
      fputc(out_byte,fptr);
      out_byte = 0x00;
   }
   post = (word & mask)>>*index;
   out_byte = out_byte | post;
   fputc(out_byte,fptr);

   *prev_left = (word & mask)<<(8-*index);  
   return;
}

void bit_0_print(int* index, char* prev_left, FILE* fptr){
   char mask = 0xFF;  
   unsigned char out_byte = mask&(*prev_left);
   (*index)++;
   
   if (*index == 8){
      *index = 0;
      fputc(out_byte, fptr);
      *prev_left = 0x00;
   }
   return;
}
