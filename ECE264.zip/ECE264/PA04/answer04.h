typedef struct _hc_node{
   struct _hc_node *left;
   struct _hc_node *right;
   struct _hc_node *next;
   long weight;
}hc_node;

typedef struct _lnode{
   char word;
   long weight;
   struct _lnode* next;
   struct _lnode* left;
   struct _lnode* right;
}lnode;


void ascii_check(char* inputfile, long** ascii_value);

void list_form(char*inputfile, long* countarr, lnode** list);

int cmp_new(long a, long b);

lnode* enqueue(lnode** pq, lnode* tree, int (*cmp_fn)(long, long));

int* file_to_array(FILE* fptr, long* count);

lnode* PO_enqueue(lnode **pq, char new_word, int new_weight, int (*cmp_fn)(long,long));

void lnode_print(FILE* fptr,const lnode *list);

int compare(long,long);

void hf_tree_helper(lnode** list);

lnode* hf_tree(char* outputfile, lnode* list); 

void print_to_file_fn(FILE* ptr, lnode* tree, char* print_arr, int index);

void post_print_helper(lnode*, FILE*,FILE* , char*, int*);

void post_print(lnode*, char*,char*);


void bit_1_print(char word, int* index, char* prev_left, FILE* fptr);


void bit_0_print(int* index, char* prev_left, FILE* fptr);
