#include <stdlib.h>
#include <stdio.h>
#include "answer07.h"

int main(int argc, char* argv[]){
   FILE* ptr;
   int nrow;
   int ncol;
   int open_loc;
   int path_num;
   int write_num;
   int row;
   int col;

   row = atoi(argv[3]);
   col = atoi(argv[4]);

   ptr = fopen(argv[1],"r");
   
   Find_maze_dimensions(ptr,&nrow,&ncol);
   printf("total row, column = %d %d\n",nrow,ncol);
   open_loc = Find_opening_location(ptr);
   printf("top open location = %d\n",open_loc);
   path_num = Count_path_locations(ptr);
   printf("total path number = %d\n",path_num);
   printf("return type = %c\n",Get_location_type(ptr,row,col));
   write_num = Represent_maze_in_one_line(argv[2],ptr);
   printf("total written number = %d\n",write_num);
   
   fclose(ptr);   
   return EXIT_SUCCESS;
}
