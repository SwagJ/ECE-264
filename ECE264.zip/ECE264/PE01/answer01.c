#include "answer01.h"
#include "stdlib.h"
#include "stdio.h"

/* Return the largest partial sum of the array */
/* int array[] = { 1, 4, -1, 6, -5, 4} */
/* the (i,j)-th partial sum is the sum from array[i] through array[j], i<=j */
/* the (0,0)-(0,5)-th partial sums are 1, 5, 4, 10, 5, 9 */
/* the (1,1)-(1,5)-th partial sums are 4, 3, 9, 4, 8 */
/* the (2,2)-(2,5)-th partial sums are -1, 5, 0, 4 */
/* the (3,3)-(3,5)-th partial sums are 6, 1, 5 */
/* the (4,4)-(4,5)-th partial sums are -5, -1 */
/* the (5,5)-th partial sum is 4 */
/* the largest partial sum of the array is therefore 10 */
/* if the len is 0, the largest partial sum is 0 */
/* you may assume that array is NULL when len is 0 */
/* but is non-NULL and correct when len is > 0 */
/* you may also assume that none of the partial sums will cause an overflow */

int largest_partial_sum(int * array, int len)
{
   int output = 0;	/* the output of the function */
   int i;	/* index of calculation within a array i */
   int j;	/* starting index of calculation in array*/
   int sum = 0; 	/* the partial sums (updated with every loop*/

   /* when array is a no-pointer array(NULL) it is treated as length is 0*/
   if (array == NULL){
	len = 0;
   }

   /* when the array is an empty one, the largest partial sum is 0*/
   if (len == 0){
	return 0;
   }

   output = array[0];	/* initialize the output */

   for ( j = 0; j < len; j++){
	sum = array[j];
	for ( i = j+1; i < len; i++){
		sum = sum + array[i];
		if ( sum > output ){
			output = sum;
		}
	}
   }
   
   return output;
}

/* Return the largest difference of the array */
/* int array[] = { 1, 4, -1, 6, -5, 4} */
/* the largest difference is 6 - (-5) = 11 */
/* if the len is 0, the largest difference is 0 */
/* if the len is 1, the largest difference is also 0 */
/* you may assume that array is NULL when len is 0 */
/* but is non-NULL and correct when len is > 0 */
/* you may assume that the largest difference will not cause an overflow */

int largest_difference(int * array, int len)
{
   int max;	/* the largest number in an array */
   int min;	/* the smallest number in an array */
   int output;	/* the largest difference between the numbers in an array*/
   int i ; 	/* the index of a number in an array */

   /* set the first element in an array as a starting max and min, then use 2 if statement to update the max and min value until find the final max and min value in an array*/
   if (array == NULL){
     len = 0;
   }
   if (len < 2){
	return 0;
   }
   else{ 
     max = array[0];
     min = array[0];
     for (i = 1; i < len; i++){
	/* find the max value of an array*/
	if ( array[i] > max){
		max = array[i];
	}
	/* find the min value of an array*/
	if (array[i] < min){
		min = array[i];
	}   
     } 
   output = max - min;
   }
   return output;
}
