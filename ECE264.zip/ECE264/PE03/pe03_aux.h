#ifndef PE03_AUX_H
#define PE03_AUX_H 

// unknown function 1
//
double unknown_function_1(double x);

// unknown function 2
//
double unknown_function_2(double x);

// unknown function 3
//
double unknown_function_3(double x);

#endif
