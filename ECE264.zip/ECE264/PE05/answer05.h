// do not modify this file
#ifndef ANSWER05_H
#define ANSWER05_H
#include "utility.h"
//
// This function takes an upper deck and a lower deck,
// interleaves the cards, and prints the results.  
//
void interleave(CardDeck upperdeck, CardDeck lowerdeck);
#endif
