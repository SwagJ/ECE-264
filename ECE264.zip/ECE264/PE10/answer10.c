#include <stdlib.h>
#include <stdio.h>
#include "answer10.h"

long* ascii_check(char* inputfile, char* outputfile){
   long* ascii_value;

   if (inputfile == NULL){
      return NULL;
   }
   if (outputfile == NULL){
      return NULL;
   }
   

   FILE* iptr = fopen(inputfile,"r");
   if(iptr == NULL){
      return NULL;
   }
   long* length = malloc(sizeof(long));
   int* input = file_to_array(iptr,length);

   if (*length == 0){
      return NULL;
   }

   ascii_value = (long*)calloc(256,sizeof(long));
   if (ascii_value == NULL){
      return NULL;
   }
   
   int i;
   long j;

   for (i = 0; i < 256; i++){
      for (j = 0; j < *length; j++){
         if (input[j] == i){
            ascii_value[i]++;
         }
      }
   }
   
   FILE* fptr;
   fptr = fopen(outputfile,"w");

   if(fptr == NULL){
      fclose(iptr);
      free(ascii_value);
      free(length);
      return NULL;
   }

   fseek(fptr, 0, SEEK_SET);
   for(i = 0; i < 256; i++){
      fprintf(fptr,"%ld\n",ascii_value[i]);
   }
   fclose(fptr);
   fclose(iptr);
   free(length);
   free(input);
   return ascii_value;
}

lnode *PQ_enqueue(lnode **pq, char new_word, long new_weight, 
                  int (*cmp_fn)(long,long))
{
   if(new_weight == 0){
   	return NULL;
   }
   lnode* n_ob = (lnode*)malloc(sizeof(lnode)*1);
   if (n_ob == NULL){
      return NULL;
   }
   n_ob->weight = new_weight;
   n_ob->word = new_word;
   n_ob->next = NULL;

   lnode dummy;
   dummy.next = *pq;

   lnode* prev = &dummy;
   lnode* curr = *pq;
   while (curr != NULL){
      if (cmp_fn(curr->weight, new_weight)){
         break;
      }else{
         prev = curr;
         curr = curr->next;
      }
   }
   prev->next = n_ob;
   n_ob->next = curr;
   *pq = dummy.next;

   return NULL;
}

lnode* list_form(char* inputfile, char* outputfile, long* countarr){
   if (outputfile == NULL){
      return NULL;
   }

   if (countarr == NULL){
      return NULL;
   } 

   int i = 0;

   lnode* list = NULL;
   for (i = 0; i < 256; i++){
      PQ_enqueue(&list,(char)i,countarr[i],compare);
   }

   FILE* optr = fopen(outputfile,"w");
   lnode_print(optr,list);
   fclose(optr);
   free(countarr);
   return list;
}


void hf_tree(char* outputfile, lnode* list){
   if (outputfile == NULL){
      return;
   }
   lnode* cur = list;
   while(cur != NULL){
   	cur->right = NULL;
   	cur->left = NULL;
   	cur = cur->next;
   }
   lnode** tree = &list;
   hf_tree_helper(tree);
   
   FILE* ptr;
   ptr = fopen(outputfile,"w");
   if (ptr == NULL){
      return;
   }

   char* print_arr;
   print_arr = malloc(sizeof(char)*500);
   if (print_arr == NULL){
      fclose(ptr);
      return;
   }

   print_to_file_fn(ptr,*tree,print_arr,0);
   fclose(ptr);
	free(print_arr);
   return;
}




//Helper Functions
//
//
//
//Start
lnode *pop(lnode **list)
{
   if (*list == NULL) {
      return NULL;
   }
   lnode *new_node = *list;
   *list = new_node->next;
   new_node->next = NULL;
   return new_node;
}


lnode *enqueue(lnode **pq, lnode* tree,
                  int (*cmp_fn)(long,long))
{
   if (tree == NULL){
      return NULL;
   }
   
   lnode dummy;
   dummy.next = *pq;

   lnode* prev = &dummy;
   lnode* curr = *pq;
   while (curr != NULL){
      if (cmp_new(tree->weight,curr->weight)){
         break;
      }else{
         prev = curr;
         curr = curr->next;
      }
   }
   prev->next = tree;
   tree->next = curr;
   *pq = dummy.next;

   return NULL;
}

int cmp_new(long a, long b){
   if (a < b){
      return 1;
   }
   return 0;
}


void hf_tree_helper(lnode** list){
   if ((*list)->next == NULL){ 
   	return;
   }
   lnode* temp1,*temp2;
   lnode* tree = (lnode*)malloc(sizeof(lnode));   
   temp1 = pop(list);
   temp2 = pop(list);
   tree->left = temp1;
   tree->right = temp2;
   tree->weight = temp1->weight+temp2->weight;
   enqueue(list, tree, cmp_new);
   hf_tree_helper(list);
}


int* file_to_array(FILE* fptr, long* count){
   if (fptr == NULL){
      return NULL;
   }
   
   int ch;
   
   fseek(fptr, 0, SEEK_END);
   *count = ftell(fptr);
   
   int* array = malloc(sizeof(int)*(*count));

   int j = 0;
   fseek(fptr, 0, SEEK_SET);
   while((ch = fgetc(fptr)) && ch != EOF){
      array[j++] = ch;
   }

   return array;
}

   
void lnode_print(FILE* fptr, const lnode *list)
{
   while (list != NULL) {
      // print the memory associated with list->ptr
      fprintf(fptr, "%c:%ld", list->word,list->weight);
      // print an arrow
      fprintf(fptr, "->");
      list = list->next;
   } 
   // print NULL and a newline after that 
   fprintf(fptr, "NULL\n");
} 

int compare(long weight_old, long weight_new){
   if(weight_old > weight_new){
      return 1;
   }
	return 0;
}


void print_to_file_fn(FILE* ptr, lnode* tree, char* print_arr, int index){
   if ((tree->left == NULL)&&(tree->right == NULL)){
      fprintf(ptr,"%c:", tree->word);
      print_arr[index] = '\0';
      int i = 0;
      while(print_arr[i] != '\0'){
         fprintf(ptr,"%c",print_arr[i]);
         i++;
      }
      fprintf(ptr,"\n");
      free(tree);
      return;
   }
   

   if (tree->left != NULL){
      print_arr[index] = '0';
      print_to_file_fn(ptr,tree->left,print_arr,index+1);
   }

   if (tree->right != NULL){
      print_arr[index] = '1';
      print_to_file_fn(ptr,tree->right,print_arr,index+1);
   }
   free(tree);
   return;
}   
