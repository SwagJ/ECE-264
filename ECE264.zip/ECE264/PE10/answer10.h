typedef struct _hc_node{
   struct _hc_node *left;
   struct _hc_node *right;
   struct _hc_node *next;
   long weight;
}hc_node;

typedef struct _lnode{
   char word;
   long weight;
   struct _lnode* next;
   struct _lnode* left;
   struct _lnode* right;
}lnode;


long* ascii_check(char* inputfile, char* outputfile);

lnode* list_form(char*inputfile, char* outputfile, long* countarr);

int cmp_new(long a, long b);

lnode* enqueue(lnode** pq, lnode* tree, int (*cmp_fn)(long, long));

int* file_to_array(FILE* fptr, long* count);

lnode* PO_enqueue(lnode **pq, char new_word, int new_weight, int (*cmp_fn)(long,long));

void lnode_print(FILE* fptr,const lnode *list);

int compare(long,long);

void hf_tree_helper(lnode** list);

void hf_tree(char* outputfile, lnode* list); 

void print_to_file_fn(FILE* ptr, lnode* tree, char* print_arr, int index);
