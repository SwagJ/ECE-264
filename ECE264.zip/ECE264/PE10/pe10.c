#include <stdio.h>
#include <stdlib.h>
#include "answer10.h"

int main(int argc, char* argv[])
{
   if (argc != 5){
      return EXIT_FAILURE;
   }
   if (argv[1] == NULL){
      return EXIT_FAILURE;
   }
   if (argv[2] == NULL){
      return EXIT_FAILURE;
   }
   if (argv[3] == NULL){
      return EXIT_FAILURE;
   }
   if (argv[4] == NULL){
      return EXIT_FAILURE;
   }

   long* ascii;
   ascii = ascii_check(argv[1],argv[2]);

   lnode* list;
   list = list_form(argv[1],argv[3],ascii);

   hf_tree(argv[4],list);
   
   return EXIT_SUCCESS;
}
