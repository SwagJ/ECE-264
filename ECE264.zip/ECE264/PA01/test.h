double test_func (double x);

