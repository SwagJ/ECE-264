#include "test.h"
#include <math.h>
#include <stdlib.h>

double test_func(double x)
{
	double p;
	p = cos(x);
	return p;
}
