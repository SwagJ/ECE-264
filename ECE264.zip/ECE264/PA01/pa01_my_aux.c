
double unknown_function_1(double x){
return sin(x);
}
double unknown_function_2(double x){
double y;
y = cos(x);
return y;
}

double unknown_function_3(double x){
double y;
y = sin(x);
return y;
}

