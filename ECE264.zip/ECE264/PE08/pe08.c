#include <stdio.h>
#include <stdlib.h>
#include "answer08.h"

void print_maze(Maze* maze);


int main(int argc, char ** argv)
{
  FILE *fptr = fopen ("sample.2.7x9", "r");
  if (fptr == NULL){
    return EXIT_FAILURE;
  }
  int num;
  Maze *maze;
  Maze *maze1;
  Maze *maze2;
  maze = Read_maze_from_2Dfile (fptr);
  print_maze(maze);
  num = Write_maze_to_2Dfile ("output.txt", maze);
  maze1 = Expand_maze_row(maze);
  print_maze(maze1);
  maze2 = Expand_maze_column (maze);
  print_maze(maze2);
  printf ("%d\n", num);
  
  Deallocate_maze_space(maze);
  Deallocate_maze_space(maze1);
  Deallocate_maze_space(maze2);
  fclose(fptr);
  return EXIT_SUCCESS;
  
}




void print_maze(Maze* maze)
{
   printf("%d\n",maze->ncol);
   printf("%d\n",maze->nrow);

   int i;
   int j;
   for (i = 0;i < maze->nrow; i++){
      for (j = 0;j < maze->ncol; j++){
         printf("%c",maze->maze_array[i][j]);
      }
      printf("\n");
   }
}
