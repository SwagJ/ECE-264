#include <stdio.h>
#include <stdlib.h>
#include "answer09.h"
#include <string.h>
void print(const void*);
void destroy(void*);
int compare(const void*,const void*);

int main(int argc,char** argv)
{
	int i = 1;
	if(argc <= 1)
	{
		return EXIT_FAILURE;
	}
	lnode* list_start = NULL;
	lnode* pq_start = NULL;
	while(i < argc)
	{
		stack_push(&list_start,argv[i]);
		PQ_enqueue(&pq_start,argv[i],compare);
		i++;
	}
	if(list_start == NULL || pq_start == NULL)
	{
	   if(list_start == NULL)
	   {
   		printf("stupid\n");
	   } 
	   else
	   {
	      printf("fool\n");
	   }
   	   return EXIT_FAILURE; 
	}	
	lnode_print(list_start,print);
	lnode_print(pq_start,print);

	lnode* listrm;
	lnode* pqrm;
	while(--i >= 1)
	{
		listrm = stack_pop(&list_start);
		lnode_print(list_start,print);
		lnode_destroy(listrm,destroy);
		pqrm = PQ_dequeue(&pq_start);
		lnode_destroy(pqrm,destroy);
		lnode_print(pq_start,print);
	}
	//lnode_destroy(list_start,destroy);

	return EXIT_SUCCESS;
}

void print(const void* in)
{
	fprintf(stdout,"%s",(char*)in);
}

void destroy(void* node)
{
//	free(node);
}

int compare(const void* in1,const void* in2)
{
	return strcmp((char*)in1,(char*)in2);
}
