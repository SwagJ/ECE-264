#include <stdlib.h>
#include <stdio.h>

#include "bmp.h"


int main(int argc, char* argv[]){
   if (argc < 3){
      return EXIT_FAILURE;
   }
   
   int ver_n = 0;
   int hor_n = 0;
   int i;
   for (i = 0; i < argc-2; i++){
      if ((argv[i][0] == '-')&&(argv[i][1] == 'v')){
         ver_n++;
      }
      if ((argv[i][0] == '-')&&(argv[i][1] == 'h')){
         hor_n++;
      }
   }
   
   FILE* iptr = fopen(argv[argc-2],"r");
   if (iptr == NULL){
      return EXIT_FAILURE;
   }
   FILE* optr = fopen(argv[argc-1],"w");
   if (optr == NULL){
      fclose(iptr);
      return EXIT_FAILURE;
   }
   
   BMP_Image* orig_image = Read_BMP_Image(iptr);
   BMP_Image* new_image = Reflect_BMP_Image(orig_image,ver_n % 2,hor_n % 2);

   i = Write_BMP_Image(optr,new_image);
   if (i == 0){
      return EXIT_FAILURE;
   }
   fclose(iptr);
   fclose(optr);
   Free_BMP_Image(new_image);
   free(orig_image);
   return EXIT_SUCCESS;
}
