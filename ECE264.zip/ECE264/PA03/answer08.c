#include <stdio.h>
#include <stdlib.h>
#include "answer08.h"

// if you want to declare and define new functions, do not name them
// with a prefix "__".  The instructors will be using functions with
// such names to test your individual functions.  You should not be 
// calling a function whose name has a prefix "__" because your program
// should compile without any functions from the instructors.
// you may put your additional functions here or at the end of this file



// allocate space from heap memory for the user-defined structure Maze, and
// allocate nrow x ncol maze and store the address in the structure (in 
// maze_array)
// also assign nrow and ncol fields in the structure accordingly
// if allocation fails, return NULL
// if allocation fails, you are also responsible for freeing the memory
// allocated in this function before the failure
// may assume that nrow and ncol are > 0

Maze *Allocate_maze_space(int nrow, int ncol)
{
   Maze* maze_allo;
   
   maze_allo = malloc(sizeof(Maze)*1);
   if (maze_allo == NULL){
      return NULL;
   }

   maze_allo->maze_array = (char**)malloc(sizeof(char*)*nrow);
   if (maze_allo->maze_array == NULL){
      free(maze_allo);
      return NULL;
   }

   maze_allo->maze_array[0] = (char*)malloc(sizeof(char)*nrow*ncol);
   if (maze_allo->maze_array[0] == NULL){
      free(maze_allo->maze_array);
      free(maze_allo);
      return NULL;
   }
   
   int i;
   for(i = 1;i < nrow;i++){
      maze_allo->maze_array[i] = &(maze_allo->maze_array[i-1][ncol]);
   }
   

   maze_allo->nrow = nrow;
   maze_allo->ncol = ncol;

   return maze_allo;
}

// free the memory used for the _maze
// you may assume that maze is not NULL, and all memory addresses are valid

void Deallocate_maze_space(Maze *maze)
{
   free(maze->maze_array[0]);
   free(maze->maze_array);
   free(maze);
}

/* Read maze in a multi-line file and store the necessary information */
/* into a 2D array of characters.  The address of the 2D array and the */
/* dimensions of the 2D array should be stored in a Maze structure allocated */
/* from the heap memory */
/* if the allocation fails, should return NULL */

Maze *Read_maze_from_2Dfile(FILE *fptr)
{
   Maze* maze_new;
   int ch;
   int ncol = 0;
   int nrow = 0;

   fseek(fptr,0,SEEK_SET);
   while((ch = fgetc(fptr)) != EOF){
      if(ch == '\n'){
         nrow++;
      }
   }
   fseek(fptr,0,SEEK_SET);
   while((ch = fgetc(fptr)) != '\n'){
         ncol++;
   }

 
   maze_new = Allocate_maze_space(nrow, ncol);
   
   int i = 0;
   int j = 0;
   char** arr = maze_new->maze_array;
   fseek(fptr,0,SEEK_SET);
   while((ch = fgetc(fptr)) != EOF){
      if(ch != '\n'){
         arr[i][j] = (char) ch;
         j++;
      }
      if(ch == '\n'){
         i++;
         j = 0;
      }
   }  
   
   return maze_new;
}

/* Write the maze into a multi-line file */
/* the maze has to stay intact */

int Write_maze_to_2Dfile(char *filename, const Maze *maze)
{
   FILE* fptr;
   fptr = fopen(filename, "w");
   fseek(fptr,0,SEEK_SET);

   int i, j, nrow, ncol, num;
   ncol = maze->ncol;
   nrow = maze->nrow;
   char** arr = maze->maze_array;   

   num = 0;
   for (i = 0; i < nrow; i++){
      for (j = 0; j < ncol; j++){
         fputc(arr[i][j],fptr);
         num++;
      }
      fputc('\n',fptr);
      num++;
   }
   fclose(fptr);
   return num;
}

/* Expand the maze from nrow x ncol to (2nrow - 1) x ncol */
/* the top half of the maze is the same as the original maze */
/* the bottom half of the maze is a reflection of the original maze */
/* You have to allocate space for a new maze */
/* the nrow and ncol fields of the new maze have to be assigned accordingly */
/* if you can't expand the maze because of memory issue, NULL should be */
/* returned */
/* the original maze has to stay intact */

Maze *Expand_maze_row(const Maze *maze)
{
   Maze* maze_app = Allocate_maze_space(2*maze->nrow-1, maze->ncol);
   if (maze_app == NULL){
      return NULL;
   }

   maze_app->nrow = 2*(maze->nrow)-1;
   maze_app->ncol = maze->ncol;
 
   int i;
   int j;
   char**arr_1 = maze->maze_array;
   char**arr_2 = maze_app->maze_array;
   for(i = 0;i < maze->nrow;i++){
      for(j = 0;j < maze->ncol;j++){
         arr_2[i][j] = arr_1[i][j];
         arr_2[maze_app->nrow - i - 1][j] = arr_1[i][j];
      }
   }

   return maze_app;
}

/* Expand the maze from nrow x ncol to nrow x 2ncol - 1 */
/* the left half of the maze is the same as the original maze */
/* the right half of the maze is a reflection of the original maze */
/* moreover, you have to create an opening between the left and right halves */
/* the opening should be at the middle row of the maze */
/* the opening must also be accessible from one of the paths in the */
/* new maze */
/* to do that, you have to convert some locations that are WALL to PATH */
/* starting from the new opening to the left and to the right until you reach */
/* a location that is adjacent to a location that is PATH */
/* You have to allocate space for a new maze */
/* the nrow and ncol fields of the new maze have to be assigned accordingly */
/* if you can't expand the maze because of memory issue, NULL should be */
/* returned */
/* the original maze has to stay intact */

Maze *Expand_maze_column(const Maze *maze)
{
   Maze* maze_app = Allocate_maze_space(maze->nrow, 2*maze->ncol-1);
   if (maze_app == NULL){
      return NULL;
   }

   maze_app->ncol = 2*(maze->ncol)-1;
   maze_app->nrow = maze->nrow;
 
   int i;
   int j;
   char** arr_1 = maze->maze_array;
   char** arr_2 = maze_app->maze_array;
   for(i = 0;i < maze->nrow;i++){
      for(j = 0;j < maze->ncol;j++){
            arr_2[i][j] = arr_1[i][j];
            arr_2[i][maze_app->ncol - j - 1] = arr_1[i][j];
      }
   }
   
   int a = (maze_app->ncol)/2;
   int b = (maze_app->nrow)/2;
   printf("col = %d\n",a);
   printf("row = %d\n",b);
   char ch = arr_2[b][a];
   char ch1 = arr_2[b-1][a];
   char ch2 = arr_2[b+1][a];  
   char ch3 = arr_2[b][a-1];
   char ch4 = arr_2[b][a+1];

   
   arr_2[b][a] = ' ';
   while((ch1 == 'X')&&(ch2 == 'X')&&(ch4 == 'X')){
      a++;
      arr_2[b][a] = ' ';
      ch = arr_2[b][a];
      ch1 = arr_2[b-1][a];
      ch2 = arr_2[b+1][a];  
      ch4 = arr_2[b][a+1];
   }
   
   a = (maze_app->ncol)/2;
   b = (maze_app->nrow)/2;

   ch = arr_2[b][a];
   ch1 = arr_2[b-1][a];
   ch2 = arr_2[b+1][a];  
   ch3 = arr_2[b][a-1];
   ch4 = arr_2[b][a+1];

   while((ch1 == 'X')&&(ch2 == 'X')&&(ch3 == 'X')){
      a--;
      arr_2[b][a] = ' ';
      ch = arr_2[b][a];
      ch1 = arr_2[b-1][a];
      ch2 = arr_2[b+1][a];  
      ch3 = arr_2[b][a-1];
   }

   return maze_app;
}

// if you want to declare and define new functions, put them here
// or at the beginning of the file

