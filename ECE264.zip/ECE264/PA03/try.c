int main() {
   char i = 'o';
   int p;
   p = (int)i;
   printf("%d\n",p);
}
