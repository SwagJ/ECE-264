#include <stdlib.h>
#include <stdio.h>

#include "bmp.h"

BMP_Image* Convert_24_to_16_BMP_Image(BMP_Image *image);

int main(int argc, char* argv[]){
   if (argc != 3){
      return EXIT_FAILURE;
   }
      
   FILE* iptr = fopen(argv[1],"r");
   if (iptr == NULL){
      return EXIT_FAILURE;
   }
   
   BMP_Image* new_image = NULL;
   BMP_Image* orig_image = Read_BMP_Image(iptr);
   if (orig_image == NULL){
      return EXIT_FAILURE;
   }
   
   if (orig_image->header.bits == 16){
      new_image = Convert_16_to_24_BMP_Image(orig_image);
   }
   if (orig_image->header.bits == 24){
      new_image = Convert_24_to_16_BMP_Image_with_Dithering(orig_image);
   }
   if (new_image == NULL){
      return EXIT_FAILURE;
   }
   FILE* optr = fopen(argv[2],"w");
   if (optr == NULL){
      fclose(iptr);
      return EXIT_FAILURE;
   }

   int i = Write_BMP_Image(optr,new_image);
   if (i == 0){
      return EXIT_FAILURE;
   }
   fclose(iptr);
   fclose(optr);
   Free_BMP_Image(new_image);
   Free_BMP_Image(orig_image);
   return EXIT_SUCCESS;
}
