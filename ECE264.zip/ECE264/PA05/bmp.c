#include <stdlib.h>
#include <stdio.h>

#include "bmp.h"


BMP_Image* Convert_24_to_16_BMP_Image(BMP_Image *oldimage);
int Is_BMP_Header_Valid(BMP_Header* header, FILE *fptr) {
  // Make sure this is a BMP file
  if (header->type != 0x4d42) {
     return FALSE;
  }
  // skip the two unused reserved fields

  // check the offset from beginning of file to image data
  // essentially the size of the BMP header
  // BMP_HEADER_SIZE for this exercise/assignment
  if (header->offset != BMP_HEADER_SIZE) {
     return FALSE;
  }
      
  // check the DIB header size == DIB_HEADER_SIZE
  // For this exercise/assignment
  if (header->DIB_header_size != DIB_HEADER_SIZE) {
     return FALSE;
  }

  // Make sure there is only one image plane
  if (header->planes != 1) {
    return FALSE;
  }
  // Make sure there is no compression
  if (header->compression != 0) {
    return FALSE;
  }

  // skip the test for xresolution, yresolution

  // ncolours and importantcolours should be 0
  if (header->ncolours != 0) {
    return FALSE;
  }
  if (header->importantcolours != 0) {
    return FALSE;
  }
  
  // Make sure we are getting 24 bits per pixel
  // or 16 bits per pixel
  // only for this assignment
  if (header->bits != 24 && header->bits != 16) {
    return FALSE;
  }

  // fill in extra to check for file size, image size
  // based on bits, width, and height

  fseek(fptr,0,SEEK_END);
  int filesize = ftell(fptr);
  if(filesize != header->size){
     return FALSE;
  }

  int imagesize = filesize - 54;
  if(imagesize != header->imagesize){
     return FALSE;
  }
  int correct_padding_byte =  (4-(header->width*header->bits/8)%4)%4;
  int curr_padding_byte = header->imagesize/header->height - header->bits/8*header->width;
  if (curr_padding_byte != correct_padding_byte){
     return FALSE;
  }
   
  return TRUE;
}

BMP_Image *Read_BMP_Image(FILE* fptr) {
  // go to the beginning of the file
   BMP_Image *bmp_image = NULL;
  //Allocate memory for BMP_Image*;
   bmp_image = malloc(sizeof(BMP_Image));
   if (bmp_image == NULL){
      return NULL;
   }
  //Read the first 54 bytes of the source into the header
   fseek(fptr,0,SEEK_SET);
   fread(bmp_image,sizeof(char), 54, fptr);
   // if read successful, check validity of header
   int i = Is_BMP_Header_Valid(&(bmp_image->header),fptr);
   if (i == 0){
      return NULL;
   }

  // Allocate memory for image data
   bmp_image->data = malloc(sizeof(char)*((bmp_image->header).imagesize));
   if (bmp_image->data == NULL){
      return NULL;
   }

   fseek(fptr,54,SEEK_SET);
   fread(bmp_image->data,sizeof(char),bmp_image->header.imagesize,fptr);
  return bmp_image;
}

int Write_BMP_Image(FILE* fptr, BMP_Image* image) 
{
   // go to the beginning of the file
   fseek(fptr,0,SEEK_SET);
   // write header
   fwrite(image,sizeof(char),54,fptr);
   // write image data
   fwrite(image->data,sizeof(char),image->header.imagesize,fptr);
   return TRUE;
}

/* The input argument is the BMP_Image pointer. The function frees memory of 
 * the BMP_Image.
 */
void Free_BMP_Image(BMP_Image* image) {
   free(image->data);
   free(image);
   return;
}

BMP_Image* Convert_16_to_24_BMP_Image(BMP_Image *image){
   BMP_Image* new_image = NULL;
   new_image = malloc(sizeof(BMP_Image));
   if (new_image == NULL){
      return NULL;
   }
 
   new_image->header = image->header;
   new_image->header.bits = 24; 
   int new_padding_byte = (4-(new_image->header.width*3)%4)%4;
   new_image->header.imagesize = (new_padding_byte+new_image->header.width*3)*new_image->header.height;
   new_image->header.size = new_image->header.imagesize + 54;
   
   int padding_byte = (image->header.imagesize/image->header.height-2*image->header.width);
   
   new_image->data = malloc(sizeof(char)*new_image->header.imagesize);
   if (new_image->data == NULL){
      free(new_image);
      return NULL;
   }
   
   int i,h;
   int l;
   long k = 0,j = 0;
   for(i = 0; i < image->header.height;i++){
      for (l = 0; l < image->header.width;l++){
         unsigned char R = ((image->data[k+1] >> 2)*255)/31;
         unsigned char G  = (((image->data[k+1]&0x03)<<3)|(image->data[k]>>5))*255/31;
         unsigned char B = (image->data[k]&0x1f)*255/31;
         k = k+2;
           
         new_image->data[j] = B;
         j = j+1;
         new_image->data[j] = G; 
         j = j+1;
         new_image->data[j] = R;
         j = j+1;
      }
      k = k+padding_byte;
      for (h = 0;h < new_padding_byte;h++){
         new_image->data[j] = 0x00;
         j++;
      }
   }
   return new_image;
}

BMP_Image* Convert_24_to_16_BMP_Image_with_Dithering(BMP_Image* image){
   int p_byte = image->header.imagesize/image->header.height - 3*image->header.width;
   int pixel_byte = image->header.bits/8;

   unsigned char*** image_arr = malloc(sizeof(char**)*(image->header.height));
   if (image_arr == NULL){
      return NULL;
   }
   image_arr[0] = malloc(sizeof(char*)*(image->header.width)*(image->header.height));
   if (image_arr[0] == NULL){
      free(image_arr);
      return NULL;
   }

   int i,j,k;
   for (i = 1; i < image->header.height; i++){
      image_arr[i] = &(image_arr[i-1][image->header.width]);
   }

   k = 0;
   for (i = 0; i < image->header.height; i++){
      for(j = 0; j < image->header.width;j++){
         image_arr[i][j] = &(image->data[k]);
         k = k + pixel_byte;
      }
      k = k + p_byte;
   }
   
   short temp;
   signed char quant_err;
   for (i = image->header.height-1; i >= 0;i--){
      for (j = 0; j < image->header.width; j++){
         for (k = 0; k < 3; k++){
            quant_err = 0;
      	    if ((i != image->header.height - 1) && (j != 0)){
               quant_err = quant_err + (image_arr[i+1][j-1][k]-(image_arr[i+1][j-1][k]>>3)*255/31);
            }
      	    if (i != image->header.height - 1){
               quant_err = quant_err + (image_arr[i+1][j][k]-(image_arr[i+1][j][k]>>3)*255/31)*5;
            }
      	    if ((i != image->header.height - 1) && (j != image->header.width - 1)){
               quant_err = quant_err + (image_arr[i+1][j+1][k]-(image_arr[i+1][j+1][k]>>3)*255/31)*3;
 	    }
      	    if (j != 0 ){
               quant_err = quant_err + (image_arr[i][j-1][k]-(image_arr[i][j-1][k]>>3)*255/31)*7 ;
            }

	    temp = quant_err/16 + image_arr[i][j][k];
            if (temp > 255){
		image_arr[i][j][k] = 0xFF;
            }else if (temp < 0){
		image_arr[i][j][k] = 0x00;
            }else{
                image_arr[i][j][k] = temp;
            }
         }
      }
   }

   BMP_Image* differ_image = Convert_24_to_16_BMP_Image(image);
   free(image_arr[0]);
   free(image_arr);
   return differ_image;   
}

BMP_Image* Convert_24_to_16_BMP_Image(BMP_Image *oldimage){
   BMP_Image* new_image = NULL;
   new_image = malloc(sizeof(BMP_Image));
   if (new_image == NULL){
      return NULL;
   }
 
   new_image->header = oldimage->header;
   new_image->header.bits = 16;
   int new_padding_byte = (4-(new_image->header.width*2)%4)%4;
   new_image->header.imagesize = (new_padding_byte+new_image->header.width*2)*new_image->header.height;
   new_image->header.size = new_image->header.imagesize + 54;
  
   int padding_byte = (oldimage->header.imagesize/oldimage->header.height-3*oldimage->header.width);
 
   new_image->data = malloc(sizeof(char)*new_image->header.imagesize);
   if (new_image->data == NULL){
      free(new_image);
      return NULL;
   }
   
   int a,h;
   int l;
   long b = 0,c = 0;
   for(a = 0; a < oldimage->header.height;a++){
      for (l = 0; l < oldimage->header.width;l++){
         unsigned short R = (0x0000)|((oldimage->data[b+2] >> 3)<<10);
         unsigned short G = (0x0000)|((oldimage->data[b+1] >> 3)<<5);
         unsigned short B = (0x0000)|(oldimage->data[b] >> 3);
         b = b+3;      

         unsigned short new_pixel = 0x0000;
         new_pixel = B|G|R;
      
         new_image->data[c] = (new_pixel & 0x00FF);
         c = c+1;
         new_image->data[c] = (new_pixel & 0xFF00)>>8; 
         c = c+1;
      }
      b = b+padding_byte;
      for (h = 0;h < new_padding_byte;h++){
         new_image->data[c] = 0x00;
         c++;
      }
   }
   return new_image;
}

